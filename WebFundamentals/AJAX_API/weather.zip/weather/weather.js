$(document).ready(function() {
  $(document).on('click', 'button', function() {
    // console.log("I was clicked!")
    var city = $('input').val();
    console.log(city);
    $.get("http://api.openweathermap.org/data/2.5/weather?q="+city+"&appid=b47b786a8f42c25d462f9beae847a42f", function(res){
      var ktemp = res.main.temp;
      // console.log(ktemp);
      var ctemp = (ktemp-273.15).toFixed(2);
      var ftemp = ((ktemp*(9/5))-459.67).toFixed(2);
      // console.log(ctemp);
      $('.weather_display').html("<h2>"+city+"</h2><p>Temperature: " + ftemp + " F&deg;");

      return false;

    }, "json");
  });
});
